package com.example.weatherapp.Food.utils;

public class APICredentials {
    public static final String type="public";
    public static final String baseUrl="https://api.edamam.com";
    public static final String appId="e79a2ded";
    public static final String appKey="36335ba8f33a77ab3250e626b9fb1512";
}
