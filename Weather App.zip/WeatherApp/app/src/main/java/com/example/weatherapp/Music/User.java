package com.example.weatherapp.Music;


public class User {

    public String birthdate;
    public String country;
    public String display_name;
    public String email;
    public String id;
}