package com.example.weatherapp.Music;

public interface VolleyCallBack {
    void onSuccess();
}
